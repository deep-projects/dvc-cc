from cc_core.version import VERSION

__version__ = VERSION
