from cc_core.agent.main import main


if __name__ == '__main__':
    exit(main())
