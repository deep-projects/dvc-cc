from cc_faice.agent.red.main import main


if __name__ == '__main__':
    exit(main())
