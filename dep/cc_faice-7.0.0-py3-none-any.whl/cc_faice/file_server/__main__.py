from cc_faice.file_server.main import main


if __name__ == '__main__':
    exit(main())
