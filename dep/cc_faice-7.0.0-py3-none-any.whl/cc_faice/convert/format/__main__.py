from cc_faice.convert.format.main import main


if __name__ == '__main__':
    exit(main())
