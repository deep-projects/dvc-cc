from cc_faice.convert.batches.main import main


if __name__ == '__main__':
    exit(main())
