from cc_faice.convert.cwl.main import main


if __name__ == '__main__':
    exit(main())
