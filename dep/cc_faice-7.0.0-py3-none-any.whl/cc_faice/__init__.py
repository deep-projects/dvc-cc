from cc_faice.version import VERSION

__version__ = VERSION
