from cc_faice.schema.list.main import main


if __name__ == '__main__':
    exit(main())
