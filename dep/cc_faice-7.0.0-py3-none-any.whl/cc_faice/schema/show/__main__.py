from cc_faice.schema.show.main import main


if __name__ == '__main__':
    exit(main())
