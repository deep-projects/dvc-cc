from dvc_cc_server.version import VERSION

__version__ = VERSION
