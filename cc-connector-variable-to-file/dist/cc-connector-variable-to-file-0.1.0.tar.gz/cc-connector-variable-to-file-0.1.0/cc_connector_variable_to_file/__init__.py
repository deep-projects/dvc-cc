from cc_connector_variable_to_file.version import VERSION

__version__ = VERSION
