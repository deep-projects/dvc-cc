from connector_variable_to_file.main import main


if __name__ == '__main__':
    exit(main())
