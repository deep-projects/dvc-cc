# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['cc_connector_variable_to_file']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['cc-connector-variable-to-file = '
                     'cc_connector_variable_to_file.main:main']}

setup_kwargs = {
    'name': 'cc-connector-variable-to-file',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Jonas',
    'author_email': 'jonas.annuscheit@gmail.com',
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
