# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['dvc_cc',
 'dvc_cc.cancel',
 'dvc_cc.dummy',
 'dvc_cc.git',
 'dvc_cc.init',
 'dvc_cc.output_to_tmp',
 'dvc_cc.run',
 'dvc_cc.run_all_defined',
 'dvc_cc.setting',
 'dvc_cc.status']

package_data = \
{'': ['*']}

install_requires = \
['cc-faice>=7.0,<8.0',
 'dvc>=0.41.0,<0.42.0',
 'keyring>=19.0,<20.0',
 'nbconvert>=5.5,<6.0',
 'numpy>=1.16,<2.0',
 'paramiko>=2.4,<3.0',
 'python-gitlab>=1.8,<2.0',
 'pyyaml>=5.1,<6.0']

entry_points = \
{'console_scripts': ['dvc-cc = dvc_cc.main:main']}

setup_kwargs = {
    'name': 'dvc-cc',
    'version': '0.3.0',
    'description': 'This connector is used to combine the work of CC (www.curious-containers.cc) and DVC (Open-source Version Control System for Machine Learning Projects).',
    'long_description': '# DVC-CC\n\nDVC-CC was developed for machine learning projects with the main target of reproducibility, simplicity and **scalability**.\n\n- Reproducibility means that all experiments created in parallel or sequentially can be reproduced by you and others who have access to your GIT and DVC repository.\n- Scalability means that these scripts ensure that you can run them on your cluster system.\n- Simplicity means that it should not cause too much more workload.\n\nTo archive this target, DVC-CC is based on the two softwares [Open-source Version Control System for Machine Learning Projects (DVC)](https://dvc.org/) and [Curious Containers (CC)](https://www.curious-containers.cc/).\n- DVC allows you to define stages that describe which command line to call, what dependencies, output, and metrics exist for this command. With the defined stages, DVC knows the pipeline of executions and ensures that changed dependencies are executed again.\n- CC is used in the backend to run your scripts in a docker on your cluster system.\n\n\n## Install\n```\npip install cc-faice\npip install https://github.com/mastaer/dvc-cc/releases/tag/dvc_cc-0.2.0-py3-none-any.whl\n```\n\n## Basic Usage\n\n### Init\n\n1. You should create a git repository\n2. Run the command: `dvc-cc init`\n3. Create a directory on a storage server and add a DVC remote to this directory. I.e.:\n    ```\n    # dvc remote add -d dvc_connection ssh://annusch@avocado01.f4.htw-berlin.de/data/ldap/jonas/test_pcam\n    dvc remote add -d dvc_connection ssh://YOURUSERNAME@YOURSERVER/PATHTODIRECTORY\n    dvc remote modify dvc_connection ask_password true\n    dvc push\n    ```\n4. check and set the settings with `dvc-cc setting all`\n\n### Define your pipeline with DVC\n\nYou can use DVC to define your pipeline.\n\n```\ndvc run -d DEPENDENCY -o SOMEOUTPUT -m SOMEMETRIC.json --no-exec python train.py\n```\n\n### RUN the defined pipeline on the server\n```\ndvc-cc run THE_EXPERIMENT_NAME\n```\n\n### check status\n```\n# get an overview over all started jobs:\ndvc-cc status --all\n\n# get a detailed view of the last runned job.\ndvc-cc status -d\n```\n\n\n## Acknowledgements\nThe CAMELYON CNNs software is developed at CBMI (HTW Berlin - University of Applied Sciences). The work is supported by the German Federal Ministry of Education and Research (project deep.TEACHING, grant number 01IS17056 and project deep.HEALTH, grant number 13FH770IX6).\n\n\n',
    'author': 'Jonas Annuscheit',
    'author_email': 'annusch@htw-berlin.de',
    'url': 'https://github.com/mastaer/dvc-cc.git',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
