from dvc_cc.run_all_defined.main import main


if __name__ == '__main__':
    exit(main())
