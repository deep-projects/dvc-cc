from dvc_cc.version import VERSION

__version__ = VERSION
