from dvc_cc.job.main import main


if __name__ == '__main__':
    exit(main())
