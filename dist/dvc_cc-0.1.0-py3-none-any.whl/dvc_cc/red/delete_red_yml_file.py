import os

DESCRIPTION = 'DVC-CC (C) 2019  Jonas Annuscheit. This software is distributed under the AGPL-3.0 LICENSE.'

def main():
    os.remove(os.path.expanduser('~/.cache/dvc_cc/created_job_description.red.yml'))
    

