from dvc_cc.status.main import main


if __name__ == '__main__':
    exit(main())
