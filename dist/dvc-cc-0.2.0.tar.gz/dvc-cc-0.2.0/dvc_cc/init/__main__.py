from dvc_cc.init.main import main


if __name__ == '__main__':
    exit(main())
