# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['dvc_cc',
 'dvc_cc.cancel',
 'dvc_cc.git',
 'dvc_cc.init',
 'dvc_cc.output_to_tmp',
 'dvc_cc.run',
 'dvc_cc.run_all_defined',
 'dvc_cc.setting',
 'dvc_cc.status']

package_data = \
{'': ['*']}

install_requires = \
['dvc>=0.41.0,<0.42.0',
 'jsonschema>=3.0,<4.0',
 'keyring>=19.0,<20.0',
 'numpy>=1.16,<2.0',
 'paramiko>=2.4,<3.0']

entry_points = \
{'console_scripts': ['dvc-cc = dvc_cc.main:main']}

setup_kwargs = {
    'name': 'dvc-cc',
    'version': '0.2.0',
    'description': 'This connector is used to combine the work of CC (www.curious-containers.cc) and DVC (Open-source Version Control System for Machine Learning Projects).',
    'long_description': '# DVC-CC\n\n...\n\n\n## Usage\n\n...\n\n## Acknowledgements\n\n...\n',
    'author': 'Jonas Annuscheit',
    'author_email': 'annusch@htw-berlin.de',
    'url': 'https://github.com/mastaer/dvc-cc.git',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
