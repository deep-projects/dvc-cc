# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['dvc_cc', 'dvc_cc.git', 'dvc_cc.job', 'dvc_cc.red']

package_data = \
{'': ['*']}

install_requires = \
['cc-faice>=6.1,<7.0',
 'dvc>=0.35.7,<0.36.0',
 'numpy>=1.16,<2.0',
 'paramiko>=2.4,<3.0']

entry_points = \
{'console_scripts': ['dvc-cc = dvc_cc.main:main']}

setup_kwargs = {
    'name': 'dvc-cc',
    'version': '0.1.0',
    'description': 'This connector is used to combine the work of CC (www.curious-containers.cc) and DVC (Open-source Version Control System for Machine Learning Projects).',
    'long_description': '# DVC-CC\n\n...\n\n\n## Usage\n\n...\n\n## Acknowledgements\n\n...\n',
    'author': 'Jonas Annuscheit',
    'author_email': 'annusch@htw-berlin.de',
    'url': 'https://github.com/mastaer/dvc-cc.git',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
