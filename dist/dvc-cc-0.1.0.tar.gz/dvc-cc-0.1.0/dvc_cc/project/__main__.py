from dvc_cc.project.main import main


if __name__ == '__main__':
    exit(main())
