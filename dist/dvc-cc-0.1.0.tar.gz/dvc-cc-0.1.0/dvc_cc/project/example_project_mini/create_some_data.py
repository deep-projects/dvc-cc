import numpy as np
import os

print('!!! CREATE THE DATASET !!!')

np.save('mydata.npy', np.random.random((1000000)))
